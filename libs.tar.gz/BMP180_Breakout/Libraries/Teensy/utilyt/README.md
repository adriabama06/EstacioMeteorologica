This folder should contain the .cpp and .h files for the library. 

This code supports i2c_t3.h library. You can use this code for Teensy devices. Example sketch is compatible with this source code.